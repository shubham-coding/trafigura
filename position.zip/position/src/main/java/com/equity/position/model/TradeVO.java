package com.equity.position.model;

import com.equity.position.utils.Action;
import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Trade Value Object representing a single equity trade")
public class TradeVO {

    @Schema(description = "Unique identifier of the trade", example = "101")
    private int id;

    @Schema(description = "Name of the equity", example = "TCS")
    private String name;

    @Schema(description = "Quantity of equity units", example = "50")
    private int quantity;

    @Schema(description = "Action performed on the trade - BUY or SELL", example = "BUY")
    private Action action;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Action getAction() {
        return action;
    }

    public void setAction(Action action) {
        this.action = action;
    }
}
