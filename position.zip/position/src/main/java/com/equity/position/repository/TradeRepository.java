package com.equity.position.repository;

import com.equity.position.entity.Trade;
import com.equity.position.utils.Action;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

@Component
public class TradeRepository {

    Map<Integer, Trade> trades = new HashMap<>();
    private final AtomicInteger idGenerator = new AtomicInteger(1);

    public Trade createTrade(int qty, String securityCode, Action action) {

        Trade trade = new Trade();
        trade.setId(idGenerator.getAndIncrement()); // Auto-generate ID
        trade.setQuantity(qty);
        trade.setSecurityCode(securityCode);
        trade.setAction(String.valueOf(action));
        trade.setCreatedTimestamp(new Date());
        trade.setVersion(1);
        trades.put(trade.getId(), trade);

        return trade;

    }

    public Trade updateTrade(int qty, String securityCode, Action action, int tradeId) {
        if (!trades.containsKey(tradeId)) {
            throw new RuntimeException("no trade found for such tradeId");
        }
        Trade trade = trades.get(tradeId);
        trade.setQuantity(qty);
        trade.setSecurityCode(securityCode);
        trade.setAction(String.valueOf(action));
        trade.setModifiedTimestamp(new Date());
        trade.setVersion(trade.getVersion() + 1);
        trades.put(tradeId, trade);
        return trade;
    }

    public void cancelTrade(int tradeId){

        if(!trades.containsKey(tradeId)){ throw new RuntimeException("no trade found for such tradeId");}
        trades.remove(tradeId);
    }
    public Trade getTrade(int id){
        if(!trades.containsKey(id)){ throw new RuntimeException("no trade found for such tradeId");}
        return trades.get(id);
    }
}


