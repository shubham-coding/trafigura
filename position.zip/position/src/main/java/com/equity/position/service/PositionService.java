package com.equity.position.service;

import com.equity.position.entity.Position;
import com.equity.position.entity.Trade;
import com.equity.position.utils.Action;

import java.util.List;
import java.util.Map;

public interface PositionService {

    public Map<String, Integer> viewPositions();

    public Trade addEquity(String securityCode, int qty, Action action);

    public void deleteEquity(int id);

    public Trade updateEquity(int id, int qty,String securityCode,Action action);
}
