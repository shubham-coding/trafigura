package com.equity.position.repository;

import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class PositionRepository {

    private Map<String, Integer> position = new ConcurrentHashMap<>();

    public void executeTrade(String securityCode, int qty) {
        if (position.containsKey(securityCode)) {
            Integer val = position.get(securityCode);
            val += qty;
            position.put(securityCode, val);
            return;
        }

        position.put(securityCode, qty);
    }

    public Map<String, Integer> getAllPositions() {
        return position;
    }


}
