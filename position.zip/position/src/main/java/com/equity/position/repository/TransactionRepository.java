package com.equity.position.repository;

import com.equity.position.entity.Transaction;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class TransactionRepository {

    private Map<Long, Transaction> transactions=new LinkedHashMap<>();

    public void MakeTransaction(Transaction txn){
        transactions.put(txn.getTransactionID(),txn);
    }
    public  Map<Long,Transaction> getAllTxn(){
        return transactions;
    }

}
