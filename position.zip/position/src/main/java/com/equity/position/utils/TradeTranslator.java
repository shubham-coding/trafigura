package com.equity.position.utils;

import com.equity.position.entity.Trade;
import com.equity.position.model.TradeVO;
import org.springframework.stereotype.Component;

@Component
public class TradeTranslator {

    public  TradeVO translateTradeResponse(Trade trade){
        TradeVO tradeRes = new TradeVO();
        tradeRes.setName(trade.getSecurityCode());
        tradeRes.setQuantity(trade.getQuantity());
        tradeRes.setId(trade.getId());
            return tradeRes;
    }
}
