package com.equity.position.service;

import com.equity.position.entity.Position;
import com.equity.position.entity.Trade;
import com.equity.position.entity.TradeVersion;
import com.equity.position.entity.Transaction;
import com.equity.position.repository.PositionRepository;
import com.equity.position.repository.TradeRepository;
import com.equity.position.repository.TradeVersionRepository;
import com.equity.position.repository.TransactionRepository;
import com.equity.position.utils.Action;
import com.equity.position.utils.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class PositionServiceImpl implements PositionService{

    @Autowired
    private TradeRepository tradeRepository ;

    @Autowired
    private PositionRepository positionRepository;

    @Autowired
    private TradeVersionRepository tradeVersionRepository ;

    @Autowired
    private TransactionRepository transactionRepository ;

    @Override
    public Map<String, Integer> viewPositions() {
       return positionRepository.getAllPositions();
    }

    @Override
    public Trade addEquity(String securityCode, int qty, Action action) {
        Trade trade=tradeRepository.createTrade(qty, securityCode, action);
        tradeVersionRepository.insertTradeVersion(trade.getId(),trade.getVersion(), Operation.INSERT.getOperation());
        Transaction transaction=new Transaction();
        transaction.setAction(action.name());
        transaction.setOperation(Operation.INSERT.getOperation());
        transaction.setQuantity(qty);
        transaction.setVersion(trade.getVersion());
        transaction.setCreatedTimestamp(new Date());
        transaction.setSecurityCode(securityCode);
        transaction.setTradeID(trade.getId());
        transactionRepository.MakeTransaction(transaction);
        positionRepository.executeTrade(securityCode,calculateQty(action.name(),qty));
return trade;

    }

    @Override
    public void deleteEquity(int id) {
        Trade trade=tradeRepository.getTrade(id);
       TradeVersion tradeVersion= tradeVersionRepository.insertTradeVersion(id,trade.getVersion()+1,Operation.DELETE.getOperation());
        Transaction transaction=new Transaction();
        transaction.setAction(trade.getAction());
        transaction.setOperation(Operation.DELETE.getOperation());
        transaction.setQuantity(trade.getQuantity());
        transaction.setVersion(trade.getVersion());
        transaction.setCreatedTimestamp(new Date());
        transaction.setSecurityCode(trade.getSecurityCode());
        transaction.setTradeID(trade.getId());


        positionRepository.executeTrade(trade.getSecurityCode(), calculateQty(trade.getAction(),trade.getQuantity()));
        tradeRepository.cancelTrade(id);
    }

    @Override
    public Trade updateEquity(int id, int qty,String securityCode,Action action) {
        Trade trade=tradeRepository.updateTrade(qty,securityCode,action,id);
        tradeVersionRepository.insertTradeVersion(trade.getId(),trade.getVersion(), Operation.UPDATE.getOperation());
        Transaction transaction=new Transaction();
        transaction.setAction(action.name());
        transaction.setOperation(Operation.UPDATE.getOperation());
        transaction.setQuantity(qty);
        transaction.setVersion(trade.getVersion());
        transaction.setCreatedTimestamp(new Date());
        transaction.setSecurityCode(securityCode);
        transaction.setTradeID(trade.getId());
        transactionRepository.MakeTransaction(transaction);
        positionRepository.executeTrade(securityCode,calculateQty(action.name(),qty));
        return trade;
    }
    private int calculateQty(String action,int qty){
        if(Action.SELL.name().equals(action)){qty=-1*qty;}
        return qty;
    }
}
