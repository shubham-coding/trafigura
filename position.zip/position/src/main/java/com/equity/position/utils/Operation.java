package com.equity.position.utils;

public enum Operation {
    INSERT("Insert Operation"),
    UPDATE("Update Operation"),
    DELETE("Delete Operation");

    private final String operation;

    Operation(String operation) {
        this.operation = operation;
    }

    public String getOperation() {
        return operation;
    }
}

