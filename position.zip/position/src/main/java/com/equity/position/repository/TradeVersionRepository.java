package com.equity.position.repository;

import com.equity.position.entity.TradeVersion;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class TradeVersionRepository {

    private Map<Integer, List<TradeVersion>> tradeVersions=new HashMap<>();

    public TradeVersion insertTradeVersion(int tradeId, int versionId, String operation){
        TradeVersion tradeVersion=new TradeVersion();
        tradeVersion.setVersion(versionId);
        tradeVersion.setTradeId(tradeId);
        tradeVersion.setOperation(operation);

        if(tradeVersions.containsKey(tradeId)){
            List<TradeVersion> version=tradeVersions.get(tradeId);
            version.add(tradeVersion);
            return tradeVersion;
        }
        List<TradeVersion> tradeVersionList=new ArrayList<>();
        tradeVersionList.add(tradeVersion);
        tradeVersions.put(tradeId,tradeVersionList);
        return tradeVersion;
    }

    public List<TradeVersion> getAllVersionTrade(int tradeId){
        if(!tradeVersions.containsKey(tradeId)){throw new RuntimeException("invalid trade Id");}
        return tradeVersions.get(tradeId);
    }
    public int getTradeVersion(int tradeId){
        if(!tradeVersions.containsKey(tradeId)){throw new RuntimeException("invalid trade Id");}
        return tradeVersions.get(tradeId).size();
    }


}
