package com.equity.position.utils;

public enum Action {

    BUY,
    SELL;
}
