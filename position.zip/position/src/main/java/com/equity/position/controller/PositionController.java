package com.equity.position.controller;

import com.equity.position.entity.Trade;
import com.equity.position.model.TradeVO;
import com.equity.position.service.PositionService;
import com.equity.position.utils.TradeTranslator;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/position")
@Tag(name = "Position Controller", description = "APIs for managing equity positions")
public class PositionController {

    @Autowired
    private PositionService positionService;

    @Autowired
    private TradeTranslator tradeTranslator;

    @Operation(summary = "View all equity positions", description = "Returns a map of equity symbols and their quantities")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved positions")
    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Integer>> viewPositions() {
        Map<String, Integer> positions = positionService.viewPositions();
        return ResponseEntity.ok(positions);
    }

    @Operation(summary = "Add a new equity trade", description = "Adds a trade with name, quantity, and action (BUY/SELL)")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Trade added successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid input")
    })
    @PostMapping("/add")
    public ResponseEntity<TradeVO> addEquity(
            @RequestBody @Parameter(description = "Trade details to be added") TradeVO tradeVO) {
        Trade trade = positionService.addEquity(tradeVO.getName(), tradeVO.getQuantity(), tradeVO.getAction());
        return ResponseEntity.ok(tradeTranslator.translateTradeResponse(trade));
    }

    @Operation(summary = "Update an existing trade", description = "Update trade by ID with new quantity, name, and action")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Trade updated successfully"),
            @ApiResponse(responseCode = "404", description = "Trade not found")
    })
    @PutMapping("/{id}")
    public ResponseEntity<TradeVO> updateEquity(
            @Parameter(description = "ID of the trade to update") @PathVariable int id,
            @RequestBody @Parameter(description = "Updated trade details") TradeVO tradeVO) {
        Trade trade = positionService.updateEquity(id, tradeVO.getQuantity(), tradeVO.getName(), tradeVO.getAction());
        return ResponseEntity.ok(tradeTranslator.translateTradeResponse(trade));
    }

    @Operation(summary = "Delete a trade", description = "Deletes a trade by its ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Trade deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Trade not found")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEquity(
            @Parameter(description = "ID of the trade to delete") @PathVariable int id) {
        positionService.deleteEquity(id);
        return ResponseEntity.noContent().build();
    }
}
