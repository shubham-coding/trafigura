package com.equity.position;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PositionApplicationTests {

	@Test
	void contextLoads() {
	}

}
