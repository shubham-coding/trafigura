const BASE_URL = 'http://localhost:8080/api/position';

export async function getHoldings() {
  const res = await fetch(`${BASE_URL}/dashboard`);
  if (!res.ok) throw new Error('Failed to fetch holdings');
  console.log("Response",res);
    const json = await res.json();
    console.log("json",json)
  const list = Object.values(json);

  return list;
}

export async function addHolding(data) {
  const res = await fetch(`${BASE_URL}/add`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error('Failed to add holding');
  return res.json();
}

export async function updateHolding(id, data) {
  const res = await fetch(`${BASE_URL}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error('Failed to update holding');
  return res.json();
}


export async function deleteHolding(id) {
  const res = await fetch(`${BASE_URL}/${id}`, {
    method: 'DELETE',
  });
  if (!res.ok) throw new Error('Failed to delete holding');
}
