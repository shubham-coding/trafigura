import React from 'react';

const HoldingRow = ({
  stock,
  editingId,
  editData,
  onEdit,
  onEditChange,
  onSave,
  onDelete
}) => {
  return (
    <tr>
      <td>
        {editingId === stock.id ? (
          <input
            type="text"
            value={editData.name}
            onChange={(e) =>
              onEditChange({ ...editData, name: e.target.value })
            }
          />
        ) : (
          stock.name
        )}
      </td>
      <td>
        {editingId === stock.id ? (
          <input
            type="number"
            value={editData.quantity}
            onChange={(e) =>
              onEditChange({ ...editData, quantity: e.target.value })
            }
          />
        ) : (
          stock.quantity
        )}
      </td>
      <td>
        {editingId === stock.id ? (
          <button onClick={() => onSave(stock.id)}>Save</button>
        ) : (
          <button onClick={() => onEdit(stock)}>Edit</button>
     
        )}
      </td>
    </tr>
  );
};

export default HoldingRow;
