import React from 'react';
import HoldingRow from './HoldingRow';

const HoldingList = ({
  holdings,
  editingId,
  editData,
  onEdit,
  onEditChange,
  onSave,
  onDelete,
}) => (
  <table border="1" cellPadding="10">
    <thead>
      <tr>
        <th>Equity Name</th>
        <th>Quantity</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      {holdings.map((stock) => (
        <HoldingRow
          key={stock.id}
          stock={stock}
          editingId={editingId}
          editData={editData}
          onEdit={onEdit}
          onEditChange={onEditChange}
          onSave={onSave}
          onDelete={onDelete}
        />
      ))}
    </tbody>
  </table>
);

export default HoldingList;
