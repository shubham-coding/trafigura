import React from 'react';

const HoldingForm = ({ newStock, onChange, onAdd }) => (
  <div className="form">
    <input
      type="text"
      name="name"
      placeholder="Equity Name"
      value={newStock.name}
      onChange={onChange}
    />
    <input
      type="number"
      name="quantity"
      placeholder="Quantity"
      value={newStock.quantity}
      onChange={onChange}
    />
    <button onClick={onAdd}>Add Holding</button>
  </div>
);

export default HoldingForm;
