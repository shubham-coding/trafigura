import React, { useState, useEffect } from 'react';
import './App.css';
import HoldingForm from './components/HoldingForm';
import HoldingList from './components/HoldingList';
import { getHoldings, addHolding, updateHolding, deleteHolding } from './services/holdingsApi';

function App() {
  const [holdings, setHoldings] = useState([]);
  const [newStock, setNewStock] = useState({ name: '', quantity: '' });
  const [editingId, setEditingId] = useState(null);
  const [editData, setEditData] = useState({ name: '', quantity: ''});

  useEffect(() => {
    getHoldings()
      .then((data) => setHoldings(data))
      .catch(console.error);
  }, []);

  const handleInputChange = (e) => {
    setNewStock({ ...newStock, [e.target.name]: e.target.value });
  };

  const handleAdd = () => {
    const data = {
      name: newStock.name.toUpperCase(),
      quantity: parseInt(newStock.quantity),
      action: 'BUY'
    };
    addHolding(data)
      .then((res) => {
        
        setHoldings([...holdings, res]);
        setNewStock({ name: '', quantity: '' });
      })
      .catch(console.error);
  };

  const handleEdit = (stock) => {
    setEditingId(stock.id);
    setEditData({ name: stock.name, quantity: stock.quantity, action: 'BUY' });
  };

  const handleSave = (id) => {
    const data = {
      name: editData.name.toUpperCase(),
      quantity: parseInt(editData.quantity),
       action: 'BUY' 
    };
    updateHolding(id, data)
      .then((res) => {
         
        setHoldings(holdings.map((h) => (h.id === id ? res : h)));
        setEditingId(null);
      })
      .catch(console.error);
  };

  const handleDelete = (id) => {
  deleteHolding(id)
    .then(() => {
      setHoldings(holdings.filter((h) => h.id !== id));
    })
    .catch(console.error);
};

  return (
    <div className="app">
      <h1>Trading Dashboard</h1>
      <HoldingForm
        newStock={newStock}
        onChange={handleInputChange}
        onAdd={handleAdd}
      />
   <HoldingList
  holdings={holdings}
  editingId={editingId}
  editData={editData}
  onEdit={handleEdit}
  onEditChange={setEditData}
  onSave={handleSave}
  onDelete={handleDelete}
/>
    </div>
  );
}

export default App;
